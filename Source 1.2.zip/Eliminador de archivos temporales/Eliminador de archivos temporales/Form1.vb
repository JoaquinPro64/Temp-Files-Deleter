﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim opcion As DialogResult
        opcion = MessageBox.Show("Se eliminara todo el contenido de la carpeta: C:\Users\%username%\AppData\Local\Temp (Puede que ciertas cosas no se puedan eliminar por estar en uso por otro proceso)",
                                 "Eliminar Temp",
                                 MessageBoxButtons.YesNo,
                                 MessageBoxIcon.Warning)
        If (opcion = DialogResult.Yes) Then
            System.Diagnostics.Process.Start("Resources\temp.bat")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim opcion As DialogResult
        opcion = MessageBox.Show("Se eliminara todo el contenido de la carpeta: C:\Windows\Prefetch (Puede que ciertas cosas no se puedan eliminar por estar en uso por otro proceso)",
                                 "Eliminar Prefetch",
                                 MessageBoxButtons.YesNo,
                                 MessageBoxIcon.Warning)
        If (opcion = DialogResult.Yes) Then
            System.Diagnostics.Process.Start("Resources\prefetch.bat")
        End If
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim opcion As DialogResult
        opcion = MessageBox.Show("Se eliminara todo el contenido de la carpeta: C:\ProgramData\Package Cache (Puede que ciertas cosas no se puedan eliminar por estar en uso por otro proceso)",
                                 "Eliminar Package Cache",
                                 MessageBoxButtons.YesNo,
                                 MessageBoxIcon.Warning)
        If (opcion = DialogResult.Yes) Then
            System.Diagnostics.Process.Start("Resources\packagecache.bat")
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim opcion As DialogResult
        opcion = MessageBox.Show("¿Realmente desea Salir?",
                                 "Salir del Programa",
                                 MessageBoxButtons.YesNo,
                                 MessageBoxIcon.Question)
        If (opcion = DialogResult.Yes) Then
            System.Windows.Forms.Application.Exit()
        End If
    End Sub
End Class
